function newPicture() {
	
	document.getElementById("image").src="image2.png";
	
}

function oldPicture() {
	
	document.getElementById("image").src="image1.png";
	
}